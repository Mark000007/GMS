package com.gymapp;

import com.gymapp.entities.*;
import com.gymapp.service.*;

import java.util.List;
import java.util.Scanner;

public class App {
    private static PersonService personService = new PersonService();
    private static MemberService memberService = new MemberService();
    private static TrainerService trainerService = new TrainerService();
    private static AdminService adminService = new AdminService();

    public static void main(String[] args) {
    	
    	initializeAdmin(); 
    	
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Welcome to Gym Management System");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    registerUser(scanner);
                    break;
                case 2:
                    loginUser(scanner);
                    break;
                case 3:
                    System.out.println("Thank you for using the Gym Management System!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void registerUser(Scanner scanner) {
        System.out.println("Register as:");
        System.out.println("1. Member");
        System.out.println("2. Trainer");

        int choice = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (choice == 1) {
            Member member = new Member();
            member.setUsername(username);
            member.setPassword(password);
            System.out.print("Enter membership plan: ");
            member.setMembershipPlan(scanner.nextLine());
            memberService.registerMember(member);
            System.out.println("Member registered successfully!");
        } else if (choice == 2) {
            Trainer trainer = new Trainer();
            trainer.setUsername(username);
            trainer.setPassword(password);
            System.out.print("Enter specialization: ");
            trainer.setSpecialization(scanner.nextLine());
            trainerService.registerTrainer(trainer);
            System.out.println("Trainer registered successfully!");
        } else {
            System.out.println("Invalid choice.");
        }
    }

    private static void loginUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        Person person = personService.loginPerson(username, password);

        if (person instanceof Member) {
            System.out.println("Member logged in successfully!");
            memberDashboard((Member) person);
        } else if (person instanceof Trainer) {
            System.out.println("Trainer logged in successfully!");
            trainerDashboard((Trainer) person);
        } else if (person instanceof Admin) {
            System.out.println("Admin logged in successfully!");
            adminDashboard((Admin) person);
        } else {
            System.out.println("Invalid username or password.");
        }
    }
    
    private static void initializeAdmin() {
        // Check if an admin account already exists
        List<Admin> admins = adminService.getAllAdmins();
        
        if (admins.isEmpty()) {
            // Create a new Admin object
            Admin admin = new Admin();
            admin.setUsername("admin"); // Set the desired admin username
            admin.setPassword("adminpassword"); // Set the desired admin password
            
            // Save the admin using the AdminService
            adminService.registerAdmin(admin);
            System.out.println("Admin account created with username: 'admin' and password: 'adminpassword'");
        } else {
            System.out.println("Admin account already exists.");
        }
    }


    private static void memberDashboard(Member member) {
        System.out.println("Welcome, " + member.getUsername());
        System.out.println("Membership Plan: " + member.getMembershipPlan());
        // Add more features here
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Member Dashboard ---");
            System.out.println("1. View Membership Plan");
            System.out.println("2. Update Profile");
            System.out.println("3. Submit Feedback");
            System.out.println("4. Logout");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Your membership plan: " + member.getMembershipPlan());
                    break;
                case 2:
                    updateMemberProfile(member, scanner);
                    break;
                case 3:
                    submitFeedback(member, scanner);
                    break;    
            
                case 4:
                    System.out.println("Logging out...");
                    return; // Exit the dashboard
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void updateMemberProfile(Member member, Scanner scanner) {
        System.out.print("Enter new username (current: " + member.getUsername() + "): ");
        String newUsername = scanner.nextLine();
        System.out.print("Enter new password: ");
        String newPassword = scanner.nextLine();
        System.out.print("Enter new membership plan (current: " + member.getMembershipPlan() + "): ");
        String newPlan = scanner.nextLine();

        member.setUsername(newUsername);
        member.setPassword(newPassword);
        member.setMembershipPlan(newPlan);

        memberService.updateMember(member);
        System.out.println("Profile updated successfully!");
    }
    private static void submitFeedback(Member member, Scanner scanner) {
        System.out.println("Enter your feedback: ");
        String feedbackText = scanner.nextLine();

        memberService.submitFeedback(member, feedbackText);
        System.out.println("Thank you for your feedback!");
    }

    

    private static void trainerDashboard(Trainer trainer) {
        System.out.println("Welcome, " + trainer.getUsername());
        System.out.println("Specialization: " + trainer.getSpecialization());
        // Add more features here


            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\n--- Trainer Dashboard ---");
                System.out.println("--------------------------------------------------");
 
                System.out.println("1. Schedule a Session");
                System.out.println("2. View Scheduled Sessions");
                System.out.println("3. Update Profile");
                System.out.println("4. Logout");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        scheduleSession(trainer, scanner);
                        break;
                    
                    case 2:
                        updateTrainerProfile(trainer, scanner);
                        break;
                    case 3:
                        System.out.println("Logging out...");
                        return; // Exit the dashboard
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }


        private static void scheduleSession(Trainer trainer, Scanner scanner) {
            System.out.print("Enter session date (YYYY-MM-DD): ");
            String sessionDate = scanner.nextLine();
            System.out.print("Enter session time (HH:MM): ");
            String sessionTime = scanner.nextLine();
            System.out.print("Enter session details: ");
            String sessionDetails = scanner.nextLine();

            // Logic to schedule the session
            trainerService.scheduleSession(trainer.getId(), sessionDate, sessionTime, sessionDetails);
            System.out.println("\n");
            System.out.println("Thank you for scheduling a Session (^_^)");
            System.out.println("-----------------------------");
        }

        private static void updateTrainerProfile(Trainer trainer, Scanner scanner) {
            System.out.print("Enter new username (current: " + trainer.getUsername() + "): ");
            String newUsername = scanner.nextLine();
            System.out.print("Enter new password: ");
            String newPassword = scanner.nextLine();
            System.out.print("Enter new specialization (current: " + trainer.getSpecialization() + "): ");
            String newSpecialization = scanner.nextLine();

            trainer.setUsername(newUsername);
            trainer.setPassword(newPassword);
            trainer.setSpecialization(newSpecialization);

            trainerService.updateTrainer(trainer);
            System.out.println("Profile updated successfully!");
        }
        


    private static void adminDashboard(Admin admin) {
        System.out.println("Welcome, Admin " + admin.getUsername());
        // Add admin features here
        
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Admin Dashboard ---");
            System.out.println("1. View All Members");
            System.out.println("2. View All Trainers");
            System.out.println("3. Add Equipment");
            System.out.println("4. View All Equipment");
            System.out.println("5. Logout");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewAllMembers();
                    break;
                case 2:
                    viewAllTrainers();
                    break;
                case 3:
                    addEquipment(scanner);
                    break;
                case 4:
                    viewAllEquipment();
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return; // Exit the dashboard
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void viewAllMembers() {
        List<Member> members = adminService.getAllMembers();
        System.out.println("\n--- List of Members ---");
        for (Member member : members) {
            System.out.println("ID: " + member.getId() + ", Username: " + member.getUsername() + ", Membership Plan: " + member.getMembershipPlan());
        }
    }

    private static void viewAllTrainers() {
        List<Trainer> trainers = adminService.getAllTrainers();
        System.out.println("\n--- List of Trainers ---");
        for (Trainer trainer : trainers) {
            System.out.println("ID: " + trainer.getId() + ", Username: " + trainer.getUsername() + ", Specialization: " + trainer.getSpecialization());
        }
    }

    private static void addEquipment(Scanner scanner) {
        System.out.print("Enter equipment name: ");
        String name = scanner.nextLine();
        System.out.print("Enter equipment quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Equipment equipment = new Equipment();
        equipment.setName(name);
        equipment.setQuantity(quantity);

        adminService.addEquipment(equipment);
        System.out.println("Equipment added successfully!");
    }

    private static void viewAllEquipment() {
        List<Equipment> equipmentList = adminService.getAllEquipment();
        System.out.println("\n--- List of Equipment ---");
        for (Equipment equipment : equipmentList) {
            System.out.println("Name: " + equipment.getName() + ", Quantity: " + equipment.getQuantity());
        }
            

    }
}


