package com.gymapp.service;

import com.gymapp.dao.MemberDAO;
import com.gymapp.entities.Member;

import java.util.Date;

import com.gymapp.dao.*;
import com.gymapp.entities.*;

public class MemberService {
    private MemberDAO memberDAO = new MemberDAO();
    private FeedbackDAO feedbackDAO = new FeedbackDAO();
    
    
    

    public void registerMember(Member member) {
        memberDAO.saveMember(member);
    }
    
    public void updateMember(Member member) {
        memberDAO.updateMember(member);
    }
    public void submitFeedback(Member member, String feedbackText) {
        Feedback feedback = new Feedback();
        feedback.setMember(member);
        feedback.setFeedbackText(feedbackText);
        feedback.setFeedbackDate(new Date());

        feedbackDAO.saveFeedback(feedback);
    }


    public Member getMemberById(int id) {
        return memberDAO.getMemberById(id);
    }
}
