package com.gymapp.service;

import java.util.List;

import org.hibernate.Transaction;

import com.gymapp.dao.*;
import com.gymapp.entities.*;
import com.gymapp.utils.HibernateUtils;

public class AdminService {
    private AdminDAO adminDAO = new AdminDAO();
    private MemberDAO memberDAO = new MemberDAO();
    private TrainerDAO trainerDAO = new TrainerDAO();
    private EquipmentDAO equipmentDAO = new EquipmentDAO();

    // Fetch all members
    public List<Member> getAllMembers() {
        return memberDAO.getAllMembers();
    }

    // Fetch all trainers
    public List<Trainer> getAllTrainers() {
        return trainerDAO.getAllTrainers();
    }

    // Add new equipment
    public void addEquipment(Equipment equipment) {
        equipmentDAO.saveEquipment(equipment);
    }

    // Fetch all equipment
    public List<Equipment> getAllEquipment() {
        return equipmentDAO.getAllEquipment();
    }
    

    public void registerAdmin(Admin admin) {
        adminDAO.saveAdmin(admin);
    }
    
    public List<Admin> getAllAdmins() {
        List<Admin> admins = null;
        Transaction transaction = null;
        try (org.hibernate.Session session = HibernateUtils.getSessionFactory().openSession()) {  // Use fully qualified name
            transaction = session.beginTransaction();
            admins = session.createQuery("FROM Admin", Admin.class).list();  // HQL query to fetch all Admins
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return admins;
    }

    
}
