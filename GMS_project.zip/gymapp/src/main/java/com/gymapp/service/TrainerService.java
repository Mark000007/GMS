package com.gymapp.service;


import java.util.List;

import com.gymapp.dao.*;
import com.gymapp.entities.*;

public class TrainerService {
    private TrainerDAO trainerDAO = new TrainerDAO();
    
    
    public void registerTrainer(Trainer trainer) {
        trainerDAO.saveTrainer(trainer);
    }
    public void updateTrainer(Trainer trainer) {
        try {
            trainerDAO.updateTrainer(trainer);
            System.out.println("Trainer profile updated successfully.");
        } catch (Exception e) {
            System.out.println("Failed to update trainer profile.");
            e.printStackTrace();
        }
    }
    public void scheduleSession(int trainerId, String sessionDate, String sessionTime, String sessionDetails) {
        try {
            // Assuming you have a Session entity and SessionDAO to handle this
            Session session = new Session();
            session.setTrainerId(trainerId);
            session.setDate(sessionDate);
            session.setTime(sessionTime);
            session.setDetails(sessionDetails);

            // Save the session using SessionDAO
            trainerDAO.scheduleSession(session);
            System.out.println("Session scheduled successfully.");
        } catch (Exception e) {
            System.out.println("Failed to schedule session.");
            e.printStackTrace();
        }
    }



    public Trainer getTrainerById(int id) {
        return trainerDAO.getTrainerById(id);
    }
}
