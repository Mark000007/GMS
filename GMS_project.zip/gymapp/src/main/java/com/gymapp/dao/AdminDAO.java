package com.gymapp.dao;

import com.gymapp.entities.Admin;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gymapp.utils.HibernateUtils;

public class AdminDAO extends PersonDAO {
    public void saveAdmin(Admin admin) {
        savePerson(admin);
    }
}

