package com.gymapp.dao;


import com.gymapp.entities.Feedback;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gymapp.utils.HibernateUtils;

public class FeedbackDAO {

    public void saveFeedback(Feedback feedback) {
        Transaction transaction = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(feedback);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Add other methods as needed
}
