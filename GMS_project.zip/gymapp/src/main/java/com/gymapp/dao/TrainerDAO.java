package com.gymapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import com.gymapp.entities.Trainer;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gymapp.utils.HibernateUtils;

public class TrainerDAO extends PersonDAO {
	
	public List<Trainer> getAllTrainers() {
        Session session = HibernateUtils.getSessionFactory().openSession();
        List<Trainer> trainers = session.createQuery("from Trainer", Trainer.class).list();
        session.close();
        return trainers;
    }
	
	
	
    public void saveTrainer(Trainer trainer) {
        savePerson(trainer);
    }
    public void updateTrainer(Trainer trainer) {
        Transaction transaction = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(trainer);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
  
    public void scheduleSession(com.gymapp.entities.Session session) {
        Transaction transaction = null;
        try (Session hibernateSession = HibernateUtils.getSessionFactory().openSession()) {
            transaction = hibernateSession.beginTransaction();
            hibernateSession.save(session);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public Trainer getTrainerById(int id) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return session.get(Trainer.class, id);
        }
    }
}

