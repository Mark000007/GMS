package com.gymapp.entities;


import javax.persistence.*;

@Entity
public class Trainer extends Person {
    private String specialization;

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

    
}


