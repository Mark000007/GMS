package com.gymapp.entities;


import javax.persistence.*;

@Entity
public class Admin extends Person {
    // Additional fields and methods if needed
	
}

